using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;
using System.Linq.Expressions;

public class Movimiento_Jugador : MonoBehaviour
{
    // Variables del jugador
    private bool cambio_Velocidad, invertido, bandera, choco;
    private float contador, limite, velocidad = 8, espera = 1.6f;

    // Componentes del jugador
    private Rigidbody2D rb;
    private SpriteRenderer sr;
    private Animator animator;
    private Vector2 movimiento;

    // Escenas y Latas en pantalla
    private Scene escena;
    private GameObject[] Latas;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        sr = GetComponent<SpriteRenderer>();
        animator = GetComponent<Animator>();
        escena = SceneManager.GetActiveScene();

        ActivarMecanicas(escena.name);
    }

    void Update()
    {
        if (cambio_Velocidad) { Velocidades(); }

        Latas = GameObject.FindGameObjectsWithTag("Lata");
        if (Latas.Length == 0)
        {
            SceneManager.LoadScene(6); // Cartel de victoria
        }
    }

    private void FixedUpdate()
    {
        if(!choco)
        {
            movimiento.x = invertido ? -Input.GetAxis("Horizontal") : Input.GetAxis("Horizontal");
            movimiento.y = invertido ? -Input.GetAxis("Vertical") : Input.GetAxis("Vertical");

            if (movimiento.x < 0)
            {
                sr.flipX = true;
            }

            if (movimiento.x > 0)
            {
                sr.flipX = false;
            }

            rb.velocity = movimiento * velocidad;
        }
        else { rb.velocity = Vector2.zero; }
    }

    private void OnTriggerEnter2D(Collider2D obj)
    {
        if (obj.CompareTag("Ovni"))
        {
            animator.SetBool("Muerte", true);
            choco = true;
            Invoke("Perdio", espera);
        }

        if (obj.CompareTag("Lata")) { Destroy(obj.gameObject); }
    }

    private void ActivarMecanicas(string escena)
    {
        if (escena == "Nivel 3")
        {
            cambio_Velocidad = true;
            limite = 2;
            bandera = false;
        }

        if (escena == "Nivel 4") { invertido = true; }
    }

    private void Velocidades()
    {
        contador += Time.deltaTime;

        if (contador >= limite)
        {
            if (bandera)
            {
                velocidad = Random.Range(4, 6);
            }
            else
            {
                velocidad = Random.Range(12, 14);
            }

            contador = 0;
            bandera = !bandera;
        }
    }

    private void Perdio()
    {
        SceneManager.LoadScene(7); // Cartel de Derrota
    }
}

