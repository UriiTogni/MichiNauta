using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Niveles : MonoBehaviour
{
    public Button[] niveles;
    public Button volver;
    private Scene escena;

    void Start()
    {
        escena = SceneManager.GetActiveScene();
        for (int i = 0; i < niveles.Length; i++)
        {
            int indice = i + 1;
            niveles[i].onClick.AddListener(() => CargarNivel(indice));
        }

        volver.onClick.AddListener(VolverAlMenu);
    }

    void CargarNivel(int i)
    {
        SceneManager.LoadScene(i);
    }

    void VolverAlMenu()
    {
        if(escena.name == "Selector" || escena.name == "Controles")
        {
            SceneManager.LoadScene(0); // Ir al menu principal
        }
        
        if(escena.name == "Victoria" || escena.name == "Derrota")
        {
            SceneManager.LoadScene(5); // Ir al selector de niveles
        }
    }
}
