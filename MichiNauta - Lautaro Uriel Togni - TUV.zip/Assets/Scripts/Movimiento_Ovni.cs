using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movimiento_Ovni : MonoBehaviour
{
    // Movimiento y limites
    [SerializeField] private float velocidadX;
    [SerializeField] private float velocidadY;
    private float x, y;
    private float limX, limY;

    // Obtener el tag del objeto
    private Rigidbody2D rb;
    
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        Verificar_Obj(rb);

        rb.velocity = new Vector2 (velocidadX, velocidadY);
    }

    private void FixedUpdate()
    {
        limX = Mathf.Clamp(rb.position.x, -x, x);
        limY = Mathf.Clamp(rb.position.y, -y, y);

        if (rb.position.x != limX)
        {
            rb.velocity = new Vector2(-rb.velocity.x, rb.velocity.y);
        }
        if (rb.position.y != limY)
        {
            rb.velocity = new Vector2(rb.velocity.x, -rb.velocity.y);
        }

        rb.position = new Vector2(limX, limY);
    }

    private void Verificar_Obj(Rigidbody2D rb)
    {
        if (rb.CompareTag("Ovni"))
        {
            x = 15.4f;
            y = 5.8f;
        }

        if (rb.CompareTag("Lata"))
        {
            x = 15.6f;
            y = 6.15f;
        }
    }
}
