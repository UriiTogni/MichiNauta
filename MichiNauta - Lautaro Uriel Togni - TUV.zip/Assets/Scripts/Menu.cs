using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Menu : MonoBehaviour
{
    public Button btn_Jugar;
    public Button btn_Controles;

    void Start()
    {
        btn_Jugar.onClick.AddListener(Niveles);
        btn_Controles.onClick.AddListener(Controles);
    }
    void Niveles()
    {
        SceneManager.LoadScene(5); // Selector de niveles
    }

    void Controles()
    {
        SceneManager.LoadScene(8); // Visualizar los controles
    }
}
